package QuanDen.demo.dto;
import QuanDen.demo.entity.BookACar;
import QuanDen.demo.entity.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.time.LocalDateTime;
import java.util.Date;

@Data
public class PaymentDto {
    private Long id;
    private Long bookACarId;
    private String NameOnCard;
    private Long CardNumber;
    private Date ExpiryDate;
    private Long SecurityCode;
    private Long ZipCode;
    private Long amount;
    private Long userId;
}
