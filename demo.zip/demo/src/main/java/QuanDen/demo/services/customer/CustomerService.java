package QuanDen.demo.services.customer;

import QuanDen.demo.dto.*;
import QuanDen.demo.entity.Payment;

import java.util.List;

public interface CustomerService {
    List<CarDto> getAllCars();
    boolean bookACar(Long carId,BookACarDto bookACarDto);

    boolean bookACar(BookACarDto bookACarDto);

    CarDto getCarById(Long carId);
    List<BookACarDto> getBookingsByUserId(Long userId);
    CarDtoListDto searchCar(SearchCarDto searchCarDto);
    boolean createPayment(Long bookACarId,PaymentDto paymentDto);
    List<PaymentDto> getPaymentByBookingId(Long bookACarId);
    BookACarDto getBookingById(Long bookACarId);
}
