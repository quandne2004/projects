package QuanDen.demo.services.customer;

import QuanDen.demo.dto.*;
import QuanDen.demo.entity.BookACar;
import QuanDen.demo.entity.Car;
import QuanDen.demo.entity.Payment;
import QuanDen.demo.entity.User;
import QuanDen.demo.enums.BookCarStatus;
import QuanDen.demo.repository.BookACarRepository;
import QuanDen.demo.repository.CarRepository;
import QuanDen.demo.repository.PaymentRepository;
import QuanDen.demo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CarRepository carRepository;
    private final UserRepository userRepository;
    private final BookACarRepository bookACarRepository;
    private final PaymentRepository paymentRepository;

    @Override
    public List<CarDto> getAllCars() {
        return carRepository.findAll().stream().map(Car::getCarDto).collect(Collectors.toList());
    }

    @Override
    public boolean bookACar(Long carId, BookACarDto bookACarDto) {
        Optional<Car> optionalCar = carRepository.findById(carId);
        Optional<User> optionalUser = userRepository.findById(bookACarDto.getUserId());

        if (optionalCar.isPresent() && optionalUser.isPresent()) {
            Car existingCar = optionalCar.get();
            BookACar bookACar = new BookACar();
            bookACar.setUser(optionalUser.get());
            bookACar.setCar(existingCar);
            bookACar.setBookCarStatus(BookCarStatus.PENDING);

            long diffInMilliSeconds = bookACarDto.getToDate().getTime() - bookACarDto.getFromDate().getTime();
            long days = TimeUnit.MILLISECONDS.toDays(diffInMilliSeconds);  // Sửa lại thành MILLISECONDS
            bookACar.setFromDate(bookACarDto.getFromDate()); // Gán giá trị từ DTO
            bookACar.setToDate(bookACarDto.getToDate());
            bookACar.setDays(days);
            bookACar.setPrice(existingCar.getPrice() * days);
            bookACarRepository.save(bookACar);

            return true;
        }

        return false;
    }


    @Override
    public boolean bookACar(BookACarDto bookACarDto) {
        return false;
    }


    @Override
    public CarDto getCarById(Long carId) {
        Optional<Car> optionalCar = carRepository.findById(carId);
        return optionalCar.map(Car::getCarDto).orElse(null);

    }

    @Override
    public List<BookACarDto> getBookingsByUserId(Long userId) {
        return bookACarRepository.findAllByUserId(userId).stream().map(BookACar::getBookACarDto).collect(Collectors.toList());
    }

    @Override
    public CarDtoListDto searchCar(SearchCarDto searchCarDto) {
        Car car = new Car();
        car.setBrand(searchCarDto.getBrand());
        car.setType(searchCarDto.getType());
        car.setTransmission(searchCarDto.getTransmission());
        searchCarDto.setColor(searchCarDto.getColor());
        ExampleMatcher exampleMatcher =
                ExampleMatcher.matchingAll()
                        .withMatcher("brand",ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase())
                        .withMatcher("type",ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase())
                        .withMatcher("transmission",ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase())
                        .withMatcher("color",ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase());
        Example<Car> carExample = Example.of(car,exampleMatcher);
        List<Car> carList = carRepository.findAll(carExample);
        CarDtoListDto carDtoListDto = new CarDtoListDto();
        carDtoListDto.setCarDtoList(carList.stream().map(Car::getCarDto).collect(Collectors.toList()));
        return carDtoListDto;
    }


    public boolean createPayment(Long bookACarId,PaymentDto paymentDto) {
        Optional<BookACar> optionalBookACar = bookACarRepository.findById(bookACarId);
        Optional<User> optionalUser = userRepository.findById(paymentDto.getUserId());

        if (optionalBookACar.isPresent() && optionalUser.isPresent()) {
            BookACar bookACar = optionalBookACar.get();

            Payment payment = new Payment();
            payment.setBookACar(bookACar); // Set the booking reference
            payment.setNameOnCard(paymentDto.getNameOnCard());
            payment.setExpiryDate(paymentDto.getExpiryDate());
            payment.setSecurityCode(paymentDto.getSecurityCode());
            payment.setCardNumber(paymentDto.getCardNumber());
            payment.setZipCode(paymentDto.getZipCode());
            payment.setUser(optionalUser.get());
            payment.setAmount(bookACar.getPrice());
            paymentRepository.save(payment);
            return true;
        } else {
            throw new RuntimeException("BookACar not found with id " + paymentDto.getBookACarId());
        }

    }

    public List<PaymentDto> getPaymentByBookingId(Long bookACarId){

        return paymentRepository.findByBookACarId(bookACarId).stream().map(Payment::getPaymentDto).collect(Collectors.toList());
    }


    public BookACarDto getBookingById(Long bookACarId){
        Optional<BookACar> optionalBookACar = bookACarRepository.findById(bookACarId);
        return optionalBookACar.map(BookACar::getBookACarDto).orElse(null);
    }


}
