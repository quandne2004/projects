package QuanDen.demo.entity;


import QuanDen.demo.dto.PaymentDto;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.Date;

@Entity
@Data
@Table(name = "payments")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String NameOnCard;
    private Long CardNumber;
    private Date ExpiryDate;
    private Long SecurityCode;
    private Long ZipCode;
    @ManyToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name = "bookACar_id",nullable = false)
    private BookACar bookACar;
    private Long amount;
    @ManyToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name = "user_id",nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private User user;



    public PaymentDto getPaymentDto(){
        PaymentDto paymentDto = new PaymentDto();

        paymentDto.setId(id);
        paymentDto.setBookACarId(bookACar.getId());
        paymentDto.setUserId(user.getId());
        paymentDto.setExpiryDate(ExpiryDate);
        paymentDto.setCardNumber(CardNumber);
        paymentDto.setNameOnCard(NameOnCard);
        paymentDto.setAmount(amount); // Đảm bảo amount là số tiền của payment, không phải giá của booking
        paymentDto.setSecurityCode(SecurityCode);
        paymentDto.setZipCode(ZipCode);
        return paymentDto;
    }

}
