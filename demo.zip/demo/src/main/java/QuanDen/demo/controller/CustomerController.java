package QuanDen.demo.controller;


import QuanDen.demo.dto.BookACarDto;
import QuanDen.demo.dto.CarDto;
import QuanDen.demo.dto.PaymentDto;
import QuanDen.demo.dto.SearchCarDto;
import QuanDen.demo.services.customer.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
@RequiredArgsConstructor
public class CustomerController {
    private final CustomerService customerService;

    @GetMapping("/car")
    public ResponseEntity<List<CarDto>> getAllCars(){
        List<CarDto> carDtoList  = customerService.getAllCars();
        return ResponseEntity.ok(carDtoList);
    }


    @PostMapping("/cars/postACar/{carId}")
    public ResponseEntity<Void> bookACar(@PathVariable Long carId,@RequestBody BookACarDto bookACarDto){
       boolean success= customerService.bookACar(carId,bookACarDto);
        if (success) return ResponseEntity.status(HttpStatus.CREATED).build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }

    @GetMapping("/car/{carId}")
    public ResponseEntity<CarDto> getCarById(@PathVariable Long carId){
       CarDto carDto = customerService.getCarById(carId);
        if (carDto == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(carDto);
    }


    @GetMapping("/car/bookings/{userId}")
    public ResponseEntity<List<BookACarDto>> getBookingsByUserId(@PathVariable Long userId){
        return ResponseEntity.ok(customerService.getBookingsByUserId(userId));
    }

    @PostMapping("/car/search")
    public ResponseEntity<?> searchCar(@RequestBody SearchCarDto searchCarDto){
        return ResponseEntity.ok(customerService.searchCar(searchCarDto));
    }

    @PostMapping("/Payment")
    public ResponseEntity<Void> createPayment( @RequestBody PaymentDto paymentDto){
        boolean success = customerService.createPayment( paymentDto.getBookACarId(),paymentDto);
        if (success){
            return ResponseEntity.status(HttpStatus.CREATED).build();
        }else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping("/payments/{bookACarId}")
    public ResponseEntity<List<PaymentDto>> getPaymentByBookingId(@PathVariable Long bookACarId) {
        List<PaymentDto> payments = customerService.getPaymentByBookingId(bookACarId);
        if (payments.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(payments);
    }

    @GetMapping("/booking/{bookACarId}")
    public ResponseEntity<BookACarDto> getBookingById(@PathVariable Long bookACarId){
        BookACarDto bookACarDto = customerService.getBookingById(bookACarId);
        if(bookACarDto == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(bookACarDto);
    }
}
