package QuanDen.demo.enums;

public enum BookCarStatus {
    PENDING,APPROVED,REJECTED
}
