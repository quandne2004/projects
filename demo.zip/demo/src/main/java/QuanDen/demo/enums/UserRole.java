package QuanDen.demo.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER
}
